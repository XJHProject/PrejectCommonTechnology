//
//  XJHNavigationController.h
//  XJH_Project
//
//  Created by 熊进辉 on 16/8/22.
//  Copyright © 2016年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "METhemeKit.h"
@interface XJHNavigationController : UINavigationController
-(void)changeNavBarType:(NavBarType)navBarType;
@end
