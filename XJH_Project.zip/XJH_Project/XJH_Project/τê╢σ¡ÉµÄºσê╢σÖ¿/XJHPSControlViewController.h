//
//  XJHPSControlViewController.h
//  XJH_Project
//
//  Created by 熊进辉 on 17/4/12.
//  Copyright © 2017年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XJHPSControlViewController : UIViewController

@end
