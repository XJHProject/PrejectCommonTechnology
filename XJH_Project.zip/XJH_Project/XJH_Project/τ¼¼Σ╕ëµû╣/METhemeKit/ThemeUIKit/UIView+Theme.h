//
//  UIView+Theme.h
//  neighborhood
//
//  Created by ss on 16/1/18.
//  Copyright © 2016年 iYaYa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIColor+Theme.h"
@interface UIView (Theme)
@property (nonatomic, copy) MEColorPicker me_backgroundColor;
@end
