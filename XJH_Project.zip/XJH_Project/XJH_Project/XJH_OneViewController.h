//
//  XJH_OneViewController.h
//  XJH_Project
//
//  Created by 熊进辉 on 16/8/22.
//  Copyright © 2016年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CYBaseViewController.h"

@interface XJH_OneViewController : CYBaseViewController
+(XJH_OneViewController *)shareVC;
@end
