//
//  AliyunPlayerSDK.h
//  AliyunPlayerSDK
//
//  Created by shiping chen on 16/5/8.
//  Copyright © 2016年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AliyunPlayerSDK.
FOUNDATION_EXPORT double AliyunPlayerSDKVersionNumber;

//! Project version string for AliyunPlayerSDK.
FOUNDATION_EXPORT const unsigned char AliyunPlayerSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AliyunPlayerSDK/PublicHeader.h>

#import <AliyunPlayerSDK/AlivcMediaPlayer.h>


